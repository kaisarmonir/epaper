<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold p-0 m-0 text-xl text-gray-800 leading-tight">
            <img src="<?php echo e(url('/logo.png')); ?>" class="Logo p-o m-o d-none sm:d-block" alt="Logo">
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12" x-data="photoGalleryApp" >


            <img src="/less.png" id="butt" class="left-mid block lg:hidden" alt="pre" x-on:click="previousPhoto()">



    <img src="/greater.png" id="butto" class="right-mid block lg:hidden" alt="next" x-on:click="nextPhoto()">


        <div class="bg-white shadow">
            <div class="w-full block sm:hidden">
                <h2 class="font-semibold p-0 m-0 text-xl text-gray-800 leading-tight">
                    <img src="<?php echo e(url('/logo.png')); ?>" class="Logo w-full " alt="Logo">
                </h2>
            </div>
        </div>





        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-1 flex text-gray-900">
                    <div class="hidden text-center items-center thumb bg-white lg:inline-block w-1/4">

                        <?php $__currentLoopData = $epaper; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $epaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <img src="/img/<?php echo e($epaper->thumbnail); ?>" :class="{'ring-2 opacity-50': currentPhoto == <?php echo e($key); ?>}" class="w-full" x-on:click="pickPhoto(<?php echo e($key); ?>)"><p text-center>page<?php echo e($key+1); ?></p><br/>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>
                    <div class="paper bg-white"><img x-ref="mainImage" src="" loading="lazy" alt="epaper"></div>
                </div>

                <div x-data="photoGalleryApp" class="max-w-xl flex flex-col">
                    <div class="flex items-center sm:h-80">


                        </div>
                        </div>
                    </div>

                </div>

        </div>
    </div>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('photoGalleryApp', () => ({
            currentPhoto: 0,
            photos: [

            <?php $__currentLoopData = $epaper2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $epaper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                "/img/<?php echo e($epaper->image); ?>",

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            init() { this.changePhoto(); },
            nextPhoto() {
                if ( this.hasNext() ) {
                    this.currentPhoto++;
                    this.changePhoto();
                }
            },
            previousPhoto() {
                if ( this.hasPrevious() ) {
                    this.currentPhoto--;
                    this.changePhoto();
                }
            },
            changePhoto() {
                this.$refs.mainImage.src = this.photos[this.currentPhoto];

            },

            pickPhoto(index) {
                this.currentPhoto = index;
                this.changePhoto();
            },
            hasPrevious() {
                return this.currentPhoto > 0;
            },
            hasNext() {
                return this.photos.length > (this.currentPhoto + 1);
            }
            }))
        })
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel-main\nn\resources\views/welcome.blade.php ENDPATH**/ ?>